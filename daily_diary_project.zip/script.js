// 루틴 저장
let routines = JSON.parse(localStorage.getItem("routines") || "[]");
let memos = JSON.parse(localStorage.getItem("memos") || "[]");

function renderRoutines() {
  const list = document.getElementById("routineList");
  list.innerHTML = "";
  routines.forEach((r, i) => {
    const li = document.createElement("li");
    li.innerHTML = r + " <button onclick='removeRoutine(" + i + ")'>삭제</button>";
    list.appendChild(li);
  });
}

function addRoutine() {
  const val = document.getElementById("newRoutine").value;
  if (!val) return;
  routines.push(val);
  localStorage.setItem("routines", JSON.stringify(routines));
  document.getElementById("newRoutine").value = "";
  renderRoutines();
}

function removeRoutine(i) {
  routines.splice(i, 1);
  localStorage.setItem("routines", JSON.stringify(routines));
  renderRoutines();
}

// 메모 저장
function renderMemos() {
  const list = document.getElementById("memoList");
  list.innerHTML = "";
  memos.forEach((m, i) => {
    const li = document.createElement("li");
    li.innerHTML = m + " <button onclick='removeMemo(" + i + ")'>삭제</button>";
    list.appendChild(li);
  });
}

function addMemo() {
  const val = document.getElementById("memoInput").value;
  if (!val) return;
  memos.push(val);
  localStorage.setItem("memos", JSON.stringify(memos));
  document.getElementById("memoInput").value = "";
  renderMemos();
}

function removeMemo(i) {
  memos.splice(i, 1);
  localStorage.setItem("memos", JSON.stringify(memos));
  renderMemos();
}

// 랜덤 질문
const questions = [
  "오늘 가장 고마웠던 일은?",
  "오늘 배운 점은?",
  "오늘 나를 웃게 한 순간은?",
  "지금 가장 원하는 것은?"
];

function showQuestion() {
  const q = questions[Math.floor(Math.random() * questions.length)];
  document.getElementById("question").innerText = q;
}

function saveAnswer() {
  const q = document.getElementById("question").innerText;
  const a = document.getElementById("answer").value;
  if (!q || !a) return;
  const saved = JSON.parse(localStorage.getItem("answers") || "[]");
  saved.push({ question: q, answer: a, date: new Date().toISOString() });
  localStorage.setItem("answers", JSON.stringify(saved));
  alert("저장되었습니다!");
  document.getElementById("answer").value = "";
}

// 초기 렌더링
renderRoutines();
renderMemos();
